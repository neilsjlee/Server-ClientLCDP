import paho.mqtt.client as mqtt
import threading
import time


class MessageProgram:

    def __init__(self, broker_ip: str, broker_port: int):
        self.mqtt_publisher = MqttPublisher(broker_ip, broker_port)
        self.local_input_listener = LocalInputListener(self.mqtt_publisher)
        self.message_listener = MessageListener()

        self.local_input_listener.start()
        self.message_listener.start()


class LocalInputListener(threading.Thread):

    def __init__(self, mqtt_publisher):
        threading.Thread.__init__(self)
        self.mqtt_publisher = mqtt_publisher

    def run(self):
        while True:
            choice = input()
            if choice == "send_x_to_server":
                self.mqtt_publisher.publish_message("testx")


class MqttPublisher:
    def __init__(self, broker_ip, broker_port):
        self.mqtt = mqtt.Client("system_pub")
        self.broker_ip = broker_ip
        self.broker_port = broker_port

    def publish_message(self, session_id, data=None):
        self.mqtt.connect(self.broker_ip, self.broker_port)
        self.mqtt.publish("system_to_mobile_app", data)
        print("mqtt 1")
        self.mqtt.loop(1)
        return True


class MessageListener(threading.Thread):

    def __init__(self):
        threading.Thread.__init__(self)
        self.cnt = 0

    def run(self):
        while True:
            print("###", self.cnt)
            time.sleep(1)
            self.cnt += 1


message_program = MessageProgram("18.117.19.11", 1883)






class CodeGenerator:

    def __init__(self):
        self.template = ""


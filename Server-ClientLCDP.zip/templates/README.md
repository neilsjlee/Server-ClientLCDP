# Painter
그림판 애플리케이션

## 기능
- 크기 조절 
- 그리기 및 채우기
- 색 선택 및 두께 조절
- 초기화 또는 그림 저장

## 사용 기술
- Front-End : Vanila JavaScript
- Back-End : 없음
- Database : 없음
- Deployed : Heroku

## Start
1. 레포지토리의 소스코드 pull
2. npm i
4. npm start
5. localhost:8080에서 확인

## Reference
- [노마드 코더 강좌](https://nomadcoders.co/javascript-for-beginners-2)